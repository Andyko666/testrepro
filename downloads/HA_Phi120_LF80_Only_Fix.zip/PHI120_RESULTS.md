# Historical Uniform-Phi1.20 Results: Not the Current Primary Scenario

This filename refers to the previous experiment where every retained route used phi=1.20, regardless of historical LF. It does not describe the current default.

The current primary rule is historical directional-route LF strictly greater than 0.80: phi=1.20; otherwise phi=1.00. Its sole default configuration is `primary_assumptions.json`.

Previously generated phi=1 and uniform-1.20 files under `validation/` or `results/` remain historical comparisons. Replacing code does not recalculate them. Run `python run_model.py` again and cite the new run's effective parameters, workbook, report, and solver status. Even when two scenarios happen to have equal total cost or spill, their per-flight demand assumptions can differ.

Spill coefficients remain cost-recovery proxies unless real directional fares are supplied; historical result files do not establish observed lost passengers or ticket revenue.
