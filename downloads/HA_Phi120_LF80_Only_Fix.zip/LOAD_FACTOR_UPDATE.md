# Existing-Project Update: LF80

Copy these replacement files into the original project folder beside `run_model.py`. Keep `data/`, the Python environment, and the existing project structure. This patch adds no new execution workflow.

The unified primary rule is historical directional-route LF > 0.80: phi=1.20; otherwise phi=1.00. The sole default-rule source is `primary_assumptions.json`. The Python overwrite was removed, the example JSON now agrees, and generated reports use the effective settings. The comparison script includes the primary cutoff plus separately labeled LF90/LF95 comparisons.

Use the existing Python/Gurobi environment and run `python run_model.py` without a uniform multiplier flag. Read the new `results/<UTC timestamp>/gurobi_results.xlsx`. Old result workbooks are not changed by applying this code correction.

To change the persistent threshold later, edit `demand_adjustment.load_factor_threshold` in `primary_assumptions.json`. Explicit CLI rules remain available for comparisons. Source data, aircraft costs, fleet/turnaround assumptions, B787 exclusion, and the optimization structure remain in use.
