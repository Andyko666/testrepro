# Hawaiian Airlines: Existing Project LF80 Correction

This is a replacement-file patch for the existing no-B787 project. Keep the original project structure, Excel sources, Python environment, and normal `run_model.py` entry point. No new launcher or VS Code workspace is required.

## Apply the correction

Extract this patch and copy its files into the existing project folder containing `run_model.py`, `gurobi_model.py`, and `requirements.txt`. Replace the matching files. Keep the original `data/`, environment folders, and other program files. Back up the files being replaced if you want to retain the previous code.

The latest large ZIP could not be transferred through the 32 MiB upload-reader limit. This correction is based on the individual source files previously supplied and supports the earlier published Phi120 project. The latest ZIP itself was not inspected.

## Unified primary demand rule

```text
historical route LF = sum(PASSENGERS) / sum(SEATS)
base demand = sum(PASSENGERS) / sum(DEPARTURES_PERFORMED)
phi = 1.20 if historical LF > 0.80, otherwise 1.00
estimated flight demand = base demand * phi
```

LF is historical directional-route load factor, calculated before optimization. Sum observations before taking the ratio; do not average aircraft-type load factors. Compare without rounding: exactly 80% does not trigger uplift. Historical B787 passengers and seats on retained routes remain historical evidence although B787 is excluded from assignment.

`primary_assumptions.json` is the only source of the default threshold. The Python entry point no longer overwrites it with a second hardcoded rule. The demand rule, examples, report labels, and tests all use the same default.

## Run the existing program again

Use the same working Python 3.12/Gurobi environment as before, from the existing project folder:

```powershell
python run_model.py
```

If using the project's local environment directly:

```powershell
.\.venv312\Scripts\python.exe run_model.py
```

Each run creates a new `results/<UTC timestamp>/` folder. Open that run's `gurobi_results.xlsx`; `Run_Summary` records the effective rule and solver status, `Assignments` records per-flight phi and spill, and `Demand_Rule_Audit` records route adjustments.

**Old Excel results and validation folders are not rewritten by replacing code. Rerun the model and use the newly created output folder for the LF80 result.** Earlier phi=1 and uniform-1.20 outputs remain separately labeled historical comparisons. Do not combine their metrics with a new scenario.

## Explicit alternatives

```powershell
python run_model.py --demand-multiplier 1.00
python run_model.py --load-factor-threshold 0.90
python run_load_factor_comparison.py
```

These deliberately run a baseline or other comparison. The default comparison includes the configured primary cutoff and separate 90%/95% cutoffs. `--demand-multiplier 1.20` is a uniform uplift on every route and bypasses the LF condition; omit it to use the default conditional rule.

Parameter precedence is generated estimates, primary JSON, optional `--parameters` JSON, then the explicit CLI demand control. Reports and workbook labels describe the actual effective configuration after overrides. A uniform override removes the inactive LF rule from saved parameters.

## Remaining assumptions

The candidate set remains B717/A330/A321neo; the B787 exclusion, source cleaning, scope rules, fleet estimates, turnaround estimates, aircraft costs, and cyclic flow model are retained. The strict comparison compatibility update is included in `gurobi_model.py` for earlier Phi120 versions.

DB1B fares are still unavailable. The spill coefficient remains a documented cost-recovery proxy based on route airborne operating cost per carried passenger, not an observed fare or actual lost revenue. The threshold and uplift are user-selected assumptions permitted as documented demand adjustments, not numerical values prescribed by the PDF. Monthly carried passengers do not identify flight-level bookings or true unmet demand.

Run the updated checks using `python -m unittest discover -v` in the complete project. See `DELIVERY_MANIFEST.json` for the patch scope; this patch contains no new operational result workbook.
