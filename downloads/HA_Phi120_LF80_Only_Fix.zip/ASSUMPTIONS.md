# Primary Assumption: Conditional Historical LF80

For each directional route, historical LF is total monthly PASSENGERS divided by total monthly SEATS. Base demand is total monthly PASSENGERS divided by total DEPARTURES_PERFORMED. Set phi=1.20 only when LF is strictly greater than 0.80; otherwise phi=1.00. Estimated flight demand is base demand multiplied by phi.

`primary_assumptions.json` defines this default once. No Python default override is applied after loading the JSON. Source observations are unchanged. Compare full-precision LF before aircraft assignment, retaining all historical aircraft observations on retained routes. Exactly LF=0.80 does not trigger uplift.

The PDF permits a documented demand adjustment but does not provide the 80% threshold or 1.20 multiplier. They are user-selected assumptions. Monthly carried passengers do not identify bookings, time-of-day demand peaks, denied boarding, or unconstrained demand. Flights on one directional route share the estimated route mean; demand and continuous spill may be fractional.

The original no-B787 scope, candidate capacities, airborne-hour costs, turnaround and fleet estimates, eligibility restrictions, and cyclic aircraft-flow constraints remain in use. Missing DB1B prices remain explicitly labeled cost-recovery proxies, not observed fares or actual lost revenue. No B787 cost is estimated.

An explicit parameter file can override the primary JSON; an explicit CLI threshold or uniform multiplier applies last. Uniform phi=1.20 is a separate sensitivity case and must not be described as the default conditional LF80 rule. The report, workbook summary, effective parameters, and per-flight phi record the actual run configuration.

Replacing code does not convert old result files to LF80. Run `python run_model.py` again and use its new timestamped output directory. The old `PHI120_RESULTS.md` and old validation folders are historical references only.
