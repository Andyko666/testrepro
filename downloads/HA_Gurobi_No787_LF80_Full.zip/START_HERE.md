# Start Here: Complete LF80 Project for VS Code

The primary rule is **historical directional-route LF > 80%: demand x 1.20; otherwise demand x 1.00**. The candidate fleet excludes the B787.

## Download, run, and view in VS Code on Windows

1. Download [HA_Gurobi_No787_LF80_Full.zip](https://github.com/Andyko666/testrepro/raw/refs/heads/codex/lf80-complete-project/downloads/HA_Gurobi_No787_LF80_Full.zip), then select **Extract All**. The archive has project files directly at its root, with no extra inner project folder.
2. Double-click `HA_Gurobi_No787_LF80.code-workspace` in the extracted folder to open the project in VS Code.
3. Press **Ctrl+Shift+B** to run the default solver task. It creates a local Python 3.12 environment if needed, installs the required packages, and runs Gurobi. Python 3.12 and a working Gurobi license are required.
4. When the task finishes, open `LATEST_RESULTS.md` in the VS Code Explorer, then press **Ctrl+Shift+V** to preview the result report.
5. Open `LATEST_assignments.csv` in VS Code to inspect the flight assignments. The report links to that run's complete Excel result workbook, which can be opened in Excel.

The complete download already contains the three Excel sources in `data/`, the PDF in `docs/`, all program/configuration files, and verified result evidence. No data copying from an older project is required. Virtual environments and license files are not distributed.

You can also open a terminal in this project and run:

```powershell
.\run_windows.cmd
```

The launcher uses its own folder, so it does not depend on a virtual environment from an older outer folder. Manual setup from the folder containing `run_model.py` and `requirements.txt` is:

```powershell
py -3.12 -m venv .venv312
.\.venv312\Scripts\python.exe -m pip install -r requirements.txt
.\.venv312\Scripts\python.exe solve_and_show.py
```

No environment activation or PowerShell execution-policy change is necessary.

## Read the result

Each solver run writes a new `results/<UTC timestamp>/` directory and refreshes the root `LATEST_RESULTS.md` report. `LATEST_assignments.csv` is refreshed when the current run has an assignment solution. The report identifies the current solver status and effective scenario; an error must not be interpreted as a new optimal solution.

In `gurobi_results.xlsx`, open `Run_Summary`, `Assignments`, `Demand_Rule_Audit`, and `Model_Assumptions`. The primary `Run_Summary` has scenario ID `lf_gt_0.8_phi_1.2_otherwise_1`, threshold 0.8, and comparison `>`.

The recorded primary result in the full package is `validation/primary_lf80/gurobi_results.xlsx`: total objective **USD 3,361,858.29**, estimated spill **820.359731**, and **54 flights with spill**. Verify the effective rule is LF strictly greater than 0.80 before using these figures. Spill is an estimate under the chosen assumptions; its cost coefficient is a cost-recovery proxy because DB1B fares are unavailable.

## Change the assumption

Edit `primary_assumptions.json`, then rerun:

```json
"load_factor_threshold": 0.8
```

This is the only default-threshold configuration. For one run with LF90 instead:

```powershell
.\.venv312\Scripts\python.exe solve_and_show.py --load-factor-threshold 0.90
```

Use `run_load_factor_comparison.py` to compare the baseline and thresholds. `--demand-multiplier 1.20` is a different, uniform uplift on every route; it bypasses LF selection.

Read `README.md` for the model, source data, output interpretation, and remaining limitations. `ASSUMPTIONS.md` defines the primary scenario. `DELIVERY_MANIFEST.json` records the verified configuration and test/solver evidence for this delivery.
