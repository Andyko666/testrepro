# Hawaiian Airlines: Unified LF80 Gurobi Model

The primary scenario uses **historical directional-route load factor greater than 80%** to select a **20% demand uplift**. Routes at or below 80% retain their historical average carried passengers per departure. This rule is configured once in `primary_assumptions.json`; the Python entry point does not contain a second default threshold.

Candidate types are **608 (B717), 696 (A330), and 721 (A321neo)**. Type 889 (B787) is excluded from aircraft assignment, available fleet, and operating-cost calculations. Code, comments, documentation, and generated outputs are English. Excel outputs use black text and a plain white background.

## Download and run in VS Code on Windows

Download [HA_Gurobi_No787_LF80_Full.zip](https://github.com/Andyko666/testrepro/raw/refs/heads/codex/lf80-complete-project/downloads/HA_Gurobi_No787_LF80_Full.zip) and select **Extract All**. Project files are directly at the archive root; there is no extra inner project folder.

Double-click `HA_Gurobi_No787_LF80.code-workspace` in the extracted folder, then press **Ctrl+Shift+B** in VS Code. The default task runs the solver through `run_windows.cmd`. When it finishes, open `LATEST_RESULTS.md` and press **Ctrl+Shift+V** to view the report. Open `LATEST_assignments.csv` to inspect assignments inside VS Code. The report links to the complete result workbook for opening in Excel.

You can also double-click `run_windows.cmd`, or run it from a terminal opened in the extracted project:

```powershell
.\run_windows.cmd
```

The launcher works from its own folder, creates a local `.venv312` using Python 3.12 when needed, installs the requirements, and runs the primary scenario through `solve_and_show.py`. That wrapper runs the existing model and refreshes the root report and assignment CSV for convenient viewing in VS Code. A working Python 3.12 installation and Gurobi license are required. Environment activation and PowerShell execution-policy changes are unnecessary.

To run the commands manually from that same project folder:

```powershell
py -3.12 -m venv .venv312
.\.venv312\Scripts\python.exe -m pip install -r requirements.txt
.\.venv312\Scripts\python.exe solve_and_show.py
```

On macOS/Linux, create a Python 3.12 environment, install `requirements.txt`, then run `python solve_and_show.py`. Gurobi 13.0.3 was used for the recorded runs. The compact formulation fits the restricted license tested here; the literal full formulation may require a larger license.

This complete GitHub distribution includes `data/`, `docs/model.pdf`, all program/configuration files, VS Code workspace/tasks, and the recorded `validation/` runs. It runs with the included source files; no data copying from an older project is required. Virtual environments and license files are not included. Earlier code-only downloads are superseded by this complete download for this workflow.

## One primary demand rule

For each directional route, compute the following from the historical monthly observations before optimization:

```text
historical_load_factor = sum(PASSENGERS) / sum(SEATS)
base_demand = sum(PASSENGERS) / sum(DEPARTURES_PERFORMED)
phi = 1.20 if historical_load_factor > 0.80, otherwise 1.00
estimated_flight_demand = base_demand * phi
```

Sum the historical observations before taking the ratios. Do not average aircraft-type load factors. Historical passengers, seats, departures, and airborne time include all historical aircraft types on retained routes, including the B787. The threshold is applied at full precision; exactly 80% does not trigger uplift. Assigned aircraft capacity and the adjusted demand do not determine the historical load factor.

Change the default in `primary_assumptions.json`:

```json
"demand_adjustment": {
  "load_factor_threshold": 0.8,
  "comparison": ">",
  "multiplier_above": 1.2,
  "multiplier_below_or_equal": 1.0
}
```

The PDF permits a documented demand-adjustment rule but does not prescribe 80% or 1.20. They are user-selected assumptions. Monthly carried passengers do not reveal flight-level booking counts, peak-time demand, or unconstrained demand. Estimated demand and spill can be fractional.

## Recorded primary result

The primary run is in `validation/primary_lf80/`. It retains 204 flights, 18 airports, and 70 directional routes. Historical LF exceeds 80% on 51 active routes covering 81 scheduled flights.

| Primary LF80 metric | Recorded value |
|---|---:|
| Operating expense | USD 3,201,237.68 |
| Spill penalty | USD 160,620.61 |
| Total objective | USD 3,361,858.29 |
| Estimated spill | 820.359731 passenger-equivalents |
| Flights with spill | 54 of 204 |
| MIP gap | 0% |
| Variables / constraints | 1,171 / 1,036 |

These are conditional model results, not observed denied boarding or actual lost revenue. Verify the run status, effective rule, and actual per-flight `phi` when quoting a result. Test outcomes and source hashes for this delivery are recorded in `DELIVERY_MANIFEST.json`.

## Compare clearly labeled scenarios

```powershell
.\.venv312\Scripts\python.exe run_load_factor_comparison.py
```

The default comparison runs the historical-mean benchmark, the configured primary cutoff, and the 90% and 95% cutoff comparisons. Its workbook is `results/load_factor_comparison_<UTC timestamp>/Load_Factor_Comparison.xlsx`. The recorded comparison is under `validation/load_factor_comparison/`.

| Scenario | Estimated spill | Flights with spill | Total objective USD |
|---|---:|---:|---:|
| Historical mean, uniform phi=1 | 0.00 | 0 | 3,201,237.68 |
| Primary: LF > 80%, phi=1.20 above cutoff | 820.36 | 54 | 3,361,858.29 |
| Comparison: LF > 90%, phi=1.20 above cutoff | 497.80 | 18 | 3,299,554.57 |
| Comparison: LF > 95%, phi=1.20 above cutoff | 0.00 | 0 | 3,201,237.68 |

No retained route exceeds historical LF 95% in these inputs. Each scenario has its own parameters, assignment files, solver log, and status. Do not combine one scenario's objective with another scenario's spill.

An explicitly different experiment is the uniform-demand stress test:

```powershell
.\.venv312\Scripts\python.exe run_sensitivity.py
```

It applies uniform phi values of 1.00, 1.05, 1.10, and 1.20. `--demand-multiplier 1.20` applies the uplift to every route and bypasses the LF condition. The uniform-1.20 case happens to have the same objective and total spill as LF80 for these inputs, but its demand settings differ. It is not the primary rule.

## Scope and unchanged source files

| Local file | Source coverage | Data rows |
|---|---|---:|
| `data/on_time.xlsx` | October 16, 2024 domestic HA schedule | 206 |
| `data/t100.xlsx` | October 2024 HA passenger segments | 104 |
| `data/costs.xlsx` | 2024 Q4 aircraft cost summary | 5 |

The earlier 208-flight scope contained HA81 AUS-HNL and HA90 HNL-BOS. They were excluded by the user before this 206-flight source was supplied because that daily scope was unbalanced at AUS and BOS under a cyclic model without repositioning. Those were scope exclusions, not a claim that the records were erroneous. The program does not remove them again.

Removing the B787 assignment option leaves HA35 PHX-HNL and HA36 HNL-PHX without a historically eligible candidate type. They are explicitly outside this run's scope, leaving **204 flights**. The program records these exclusions and reasons in `prepared/`; it does not delete rows from the source workbooks. Other historically B787-operated flights remain when another candidate type is historically eligible.

Tail-type inference uses the supplied 206-flight source and full historical eligibility before the PHX scope exclusions. Historical demand and route airborne time retain B787 observations on retained routes. Spill-penalty calibration uses only candidate types with supplied costs, so it does not require an estimated B787 cost.

The supplied PDF is saved as `docs/model.pdf`. Its uploaded filename referred to Milestone 3, while its content is the complete Milestone 4 model. Fixed schedule, flight coverage, spill, cyclic type-specific flow, readiness, and fleet caps follow that structure within the stated scope.

## Missing inputs and limitations

| Input or issue | Treatment and remaining limitation |
|---|---|
| DB1B route fares unavailable | Use candidate-aircraft monthly route airborne operating cost divided by candidate-aircraft carried passengers. This is a **cost-recovery spill-penalty proxy**, not an observed fare, contribution margin, or actual lost revenue. It substitutes for the PDF-requested DB1B source. |
| Fleet availability | Scenario fleet is 16 B717, 16 A330, and 17 A321neo, inferred from observed tails and historical compatibility. Maintenance, spares, international commitments, and five ambiguous tail types remain uncertain; no FAA verification is claimed. |
| Turnaround times | Proxies are 30/100/75 minutes for 608/696/721, using positive scheduled-dwell P10 rounded up to five minutes. These are not approved operational minima. |
| Costs | Use supplied airborne-hour costs for candidate types. Operating cost is airborne hours times airborne-hour cost. The processed cost summary is not independently authenticated raw Form 41 evidence. |
| Monthly-average demand | All flights on a directional route use the same estimated demand; peak-time flight demand remains unknown. |
| One planned overlap | N493HA, HA241 to HA296, has a planned ground interval of -15 minutes versus 44 minutes actual. Preserve the source times, flag the overlap, and exclude it from positive-dwell turnaround samples. |
| Ten monthly rows with zero scheduled departures | Retain and flag them because performed departures are positive. Ratios use performed departures. |
| Two nonidentical HNL-LAX/type696 rows | Aggregate both: 69 departures, 17,495 passengers, 19,182 seats, and 20,245 airborne minutes. They are not deleted as duplicates. |
| Aircraft types 837 and 889 | Preserve source costs/history; neither is a candidate assignment type. |

Dates and clocks are converted with IANA time zones, including Phoenix's no-DST rule. Full dates are retained before building daily event times. The 206-flight source airport totals balance; removing the two opposite PHX flights preserves balance. The solved model is also checked at all original shared events for timing, aircraft flow, and fleet caps.

## Parameter precedence and commands

Estimated mode applies generated source estimates, then `primary_assumptions.json`, then an optional `--parameters` JSON. Explicit CLI demand controls apply last. `--load-factor-threshold` and `--demand-multiplier` are mutually exclusive. A threshold CLI rule replaces route exceptions; a uniform CLI factor replaces demand on all retained routes. Strict mode does not automatically apply generated assumptions or the primary JSON. The commands below use `solve_and_show.py` so the root VS Code report also reflects the selected run; `run_model.py` remains the underlying model entry point.

```powershell
.\.venv312\Scripts\python.exe solve_and_show.py --load-factor-threshold 0.90 --high-load-multiplier 1.20
.\.venv312\Scripts\python.exe solve_and_show.py --demand-multiplier 1.00
.\.venv312\Scripts\python.exe solve_and_show.py --parameters parameters_example.json
.\.venv312\Scripts\python.exe solve_and_show.py --validate-only
.\.venv312\Scripts\python.exe solve_and_show.py --mode strict --validate-only
```

With the supplied files, strict mode reports 76 missing inputs: 70 route fares, three turnarounds, and three fleet counts. Missing inputs are not mathematical infeasibility. `parameters_example.json` shows the primary conditional rule and the scenario fleet/turnaround estimates.

Optional locally supplied directional fares use a CSV with `origin,dest,fare_usd`, one positive finite USD price per route:

```powershell
.\.venv312\Scripts\python.exe solve_and_show.py --fares my_route_fares.csv
```

Matched fares take precedence over the proxy. Any unmatched routes still use the proxy in estimated mode. The import is recorded separately; the program does not certify an external file as genuine DB1B data. Source files can also be selected with `--on-time`, `--t100`, and `--costs`.

## Outputs and verification

The VS Code build task and `run_windows.cmd` use `solve_and_show.py`, which runs the model and updates `LATEST_RESULTS.md` at the project root. Open this file in VS Code and press **Ctrl+Shift+V** for a formatted report. `LATEST_assignments.csv` contains the current assignment table when a solution exists. If a current run has no assignment, a previous root assignment CSV is removed rather than presented as the new result. The report records the current status and links to the actual output folder.

A new run creates `results/<UTC timestamp>/`. The complete `gurobi_results.xlsx` can be opened in Excel; a VS Code spreadsheet extension is optional. Its sheets include:

- `Run_Summary`: solver status, objective, gap, scenario ID, and effective demand settings. The primary run has `scenario_id=lf_gt_0.8_phi_1.2_otherwise_1`, threshold 0.8, and comparison `>`.
- `Assignments`: flight/type assignment, historical load factor, actual phi, estimated demand/spill, and cost components.
- `Demand_Rule_Audit`: historical route load factors and the applied demand adjustments.
- `Model_Assumptions`: source and estimation explanations.

The same directory contains `RUN_REPORT.md`, `run_summary.json`, `effective_parameters.json`, CSV outputs, `model.lp`, `gurobi.log`, and source/preparation audits. `primary_assumptions_applied` records that the primary file was loaded; `primary_demand_rule_is_effective` records whether its rule still governs after overrides. `ground_inventory.csv` contains integer inventories at all common events; inventory rows across different times must not be added as separate aircraft. The model assigns aircraft types, not specific tail rotations.

Nonempty output directories are not overwritten. A feasible time-limit incumbent is not labeled optimal. Exit codes 0/1/2/3 mean validated-or-feasible/error/missing-inputs/no-incumbent. An IIS is written when Gurobi proves infeasibility.

Compact mode exactly eliminates unchanged inventory variables and redundant fleet cuts, then reconstructs and checks every common PDF event. Use `--formulation full` for the literal shared-event model; it may need a larger license. Licensing errors are reported separately from infeasibility.

Run the tests from the project folder:

```powershell
.\.venv312\Scripts\python.exe -m unittest discover -v
```

See `DELIVERY_MANIFEST.json` for the recorded test count, source hashes, primary rule, and validated result locations.
