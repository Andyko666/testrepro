#!/usr/bin/env python3
"""Run Gurobi and refresh the result files that can be opened in VS Code."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import os
from pathlib import Path
import shutil
import sys

from run_model import ROOT, main as run_model


def publish_latest(output: Path, exit_code: int, use_output: bool = True) -> None:
    """Publish only this invocation's report; remove a stale assignment copy."""
    output = output.resolve()
    try:
        display_path = Path(os.path.relpath(output, ROOT)).as_posix()
    except ValueError:
        # Windows paths on different drives cannot be made relative.
        display_path = output.as_posix()
    lines = [
        "# Latest Gurobi Run", "",
        f"Updated UTC: {datetime.now(timezone.utc).isoformat()}", "",
        f"Run exit code: **{exit_code}**.", "",
        f"Output folder: `{display_path}`.", "",
    ]
    report = output / "RUN_REPORT.md"
    if use_output and report.is_file():
        lines += [report.read_text(encoding="utf-8"), ""]
    else:
        lines += [
            "This invocation did not produce a new completed run report. "
            "Read the terminal error above. A previous run is not displayed as the current result.", "",
        ]

    latest_assignments = ROOT / "LATEST_assignments.csv"
    assignments = output / "assignments.csv"
    if use_output and assignments.is_file():
        shutil.copy2(assignments, latest_assignments)
        lines += [
            "## Open the flight assignments in VS Code", "",
            "Open [LATEST_assignments.csv](LATEST_assignments.csv) to read this run's flight-by-flight solution. "
            "Open this Markdown file and press Ctrl+Shift+V for its formatted preview.", "",
            f"[Open the Excel result](<{display_path}/gurobi_results.xlsx>). Open that file in Excel "
            "for the full workbook; VS Code can read the Markdown report and CSV without an Excel extension.", "",
        ]
    else:
        latest_assignments.unlink(missing_ok=True)
        lines += ["No flight assignment was produced by this invocation.", ""]

    (ROOT / "LATEST_RESULTS.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"VS Code report: {ROOT / 'LATEST_RESULTS.md'}", flush=True)
    if latest_assignments.is_file():
        print(f"VS Code assignments: {latest_assignments}", flush=True)


def main(argv=None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--output", type=Path)
    options, _ = parser.parse_known_args(arguments)
    output = options.output or ROOT / "results" / datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f_UTC")
    if options.output is None:
        arguments += ["--output", str(output)]
    occupied = output.exists() and any(output.iterdir())
    exit_code = run_model(arguments)
    # The underlying runner refuses occupied directories without writing a new
    # report. In that case their existing files must not look like fresh results.
    publish_latest(output, exit_code, use_output=not occupied)
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
