# Primary Modeling Assumptions: Historical LF80

## Demand rule

The primary demand rule is defined in `primary_assumptions.json`, loaded automatically in estimated mode. There is no second threshold override in the Python entry point.

```text
LF_r = sum_route(PASSENGERS) / sum_route(SEATS)
base_demand_r = sum_route(PASSENGERS) / sum_route(DEPARTURES_PERFORMED)
phi_r = 1.20 if LF_r > 0.80, otherwise 1.00
q_f = base_demand_r * phi_r
```

LF uses the historical directional-route passenger and seat totals before optimization, including historical B787 observations on retained routes. Compare at full precision. LF exactly 0.80 receives no uplift. Do not average row/type LF ratios or use assigned capacity or adjusted demand to select the multiplier.

The user selected the 80% threshold and 1.20 multiplier. The PDF allows a documented demand-adjustment rule but provides neither number. The uplift is a modeling assumption for potential demand beyond carried passengers, not measured bookings, denied boarding, or a calibrated estimate of unconstrained demand. All flights on the same directional route share the same monthly-average demand. Demand and continuous spill can be fractional.

Example: LAX-HNL historical mean is 25,511/101 = 252.584158 passengers and historical LF is 25,511/28,493 = 0.895342717. LF80 therefore gives demand 303.100990. An assigned A330 with 278 seats has estimated spill 25.100990. Under the separate LF90 comparison, this route receives no uplift.

## Aircraft and operating assumptions

- Candidate types are 608/B717, 696/A330, and 721/A321neo. Capacities are 128/278/189 seats. B787 is excluded from assignment, fleet counts, and operating cost at the user's request; no B787 cost is estimated.
- The supplied source already has 206 flights after the earlier user-directed AUS/BOS scope exclusions. HA35 PHX-HNL and HA36 HNL-PHX have no remaining historical candidate type after B787 exclusion, so the model explicitly scopes them out. The active model has 204 flights. Source workbooks are unchanged.
- Route demand and airborne hours retain all historical aircraft observations on retained routes, including B787. Removing an assignment option does not remove its historical passengers or flying time.
- Supplied 608/696/721 airborne-hour costs are used. Flight operating cost is route-average airborne hours multiplied by the assigned type's airborne-hour cost, following the PDF time unit.
- Turnaround proxies are 30/100/75 minutes, derived from positive planned ground-dwell P10 rounded up to five minutes. Dwell contains idle time; these values are not approved operational minima.
- The fleet scenario is 16/16/17, inferred from observed tails and historical compatibility. Five ambiguous tail types, reserves, maintenance, and international commitments remain uncertain. Current FAA registry verification is not claimed.
- Fixed schedule, coverage, cyclic integer inventories, type-specific readiness, no repositioning, and no passenger recapture follow the PDF model structure. Historically observed route/type compatibility defines eligible assignments in this implementation.

## Missing DB1B prices

Directional DB1B fares are unavailable in the supplied data. The spill-penalty coefficient is approximated by candidate-aircraft route monthly airborne operating cost divided by candidate-aircraft carried passengers. This **cost-recovery proxy is not an observed fare or actual lost revenue**. It substitutes for the PDF-requested DB1B source while retaining the objective's operating-cost-plus-spill-penalty structure.

Optional positive directional USD fares supplied through `--fares` take precedence on matching routes. Unmatched routes retain the labeled proxy in estimated mode. No B787 operating cost is needed for proxy calibration because only candidate types with supplied costs enter that calculation.

## Scenario separation

The primary LF80 result is `validation/primary_lf80/`: USD 3,361,858.29 total cost, 820.359731 estimated spill, and 54 flights with spill. Its demand is uplifted on 51 routes/81 flights, not all 204 flights.

`validation/load_factor_comparison/` records separate historical-mean, LF80, LF90, and LF95 scenarios. Uniform demand scenarios from `run_sensitivity.py` are an additional experiment. A uniform 1.20 run can share the LF80 total objective and spill for these data without sharing its demand assumptions. Use the effective rule and per-flight phi to identify a scenario.

## Reproduction and precedence

```powershell
.\.venv312\Scripts\python.exe run_model.py
```

This uses the primary LF80 rule. The following is a different scenario:

```powershell
.\.venv312\Scripts\python.exe run_model.py --demand-multiplier 1.20
```

It bypasses LF selection and gives every retained route phi=1.20. Use `--demand-multiplier 1.00` for the historical-mean benchmark.

In estimated mode, generated source estimates are followed by the primary JSON, an optional `--parameters` JSON, and then the explicit CLI demand control. An explicit demand-adjustment JSON clears generated per-route phi defaults; explicit route exceptions in that same override can then take precedence over its rule. A CLI threshold or uniform factor is applied last and clears conflicting demand choices. Strict mode auto-applies neither generated estimates nor the primary JSON.

The preparation stage retains its separate phi=1 source-estimate audit. Final settings are in each run's `effective_parameters.json`, `calculated_flight_parameters.csv`, `run_summary.json`, `RUN_REPORT.md`, and result workbook. Final audit fields describe the effective rule; the primary configuration is provenance rather than proof that no override occurred.
