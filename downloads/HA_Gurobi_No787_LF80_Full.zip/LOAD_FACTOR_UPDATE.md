# Unified Conditional Load-Factor Update: LF80

This version unifies the primary configuration, Python entry point, report text, examples, comparison runner, documentation, and tests around **historical LF > 0.80 => phi=1.20; otherwise phi=1.00**.

## Install this complete version

Download [HA_Gurobi_No787_LF80_Full.zip](https://github.com/Andyko666/testrepro/raw/refs/heads/codex/lf80-complete-project/downloads/HA_Gurobi_No787_LF80_Full.zip), then select **Extract All** into a new folder. The ZIP places project files directly at its root and includes the source Excel data, PDF, all code/configuration, and verified results. No data copying from an older project is required. Virtual environments and license files are not distributed.

Double-click `HA_Gurobi_No787_LF80.code-workspace` in the extracted folder to open VS Code, then press **Ctrl+Shift+B** to run the solver task. Open `LATEST_RESULTS.md` and press **Ctrl+Shift+V** to view the report, or open `LATEST_assignments.csv` to inspect the flight assignments. Read `START_HERE.md` first. Python 3.12 and a working Gurobi license are required.

The old `PHI120_RESULTS.md` described a uniform-uplift primary scenario. It is not part of this unified version. Do not treat that old file or an old `validation/` folder as evidence of the new primary rule. Fresh primary evidence is in `validation/primary_lf80/` in the full package.

## Run and change the threshold

```powershell
.\run_windows.cmd
```

The launcher uses its own project folder, creates a local Python 3.12 environment when needed, installs requirements, and calls `solve_and_show.py` to run the existing solver and refresh the root report. No environment activation or execution-policy change is required.

The sole default rule source is `primary_assumptions.json`. To change the persistent threshold, edit `demand_adjustment.load_factor_threshold` there. For example, `0.8` means 80% and `0.9` means 90%. Do not add another hardcoded override in `run_model.py`.

A one-run override is explicit:

```powershell
.\.venv312\Scripts\python.exe solve_and_show.py --load-factor-threshold 0.90 --high-load-multiplier 1.20
```

`--demand-multiplier 1.20` is the separate uniform case: it bypasses the LF condition and uplifts every retained route.

## Exact definition

```text
LF = sum historical directional-route PASSENGERS / sum historical directional-route SEATS
base_demand = sum historical directional-route PASSENGERS / sum DEPARTURES_PERFORMED
phi = 1.20 if LF > 0.80, otherwise 1.00
estimated_flight_demand = base_demand * phi
```

Compare without rounding. Exactly 80% receives phi=1.00. Sum passenger and seat observations before dividing, including historical B787 flights on retained routes. Assigned aircraft capacity and adjusted demand do not enter historical LF. The PDF allows a documented adjustment rule but does not specify the chosen threshold or uplift.

## Compare and read results

```powershell
.\.venv312\Scripts\python.exe run_load_factor_comparison.py
```

The default comparison includes the historical-mean benchmark, the primary configured cutoff, and LF90/LF95. Each case reruns Gurobi and writes its own output folder. Read `Load_Factor_Comparison.xlsx` in the generated comparison directory. Uniform scenarios remain available through `run_sensitivity.py`, labeled as a different experiment.

For the primary LF80 run, check:

- Effective threshold 0.80 and strict comparison `>`.
- Phi=1.20 on 51 active routes/81 scheduled flights; phi=1.00 elsewhere.
- 54 flights with spill and 820.359731 estimated spill in total.
- USD 3,201,237.68 operating expense plus USD 160,620.61 spill penalty, totaling USD 3,361,858.29.

`LATEST_RESULTS.md` identifies the current solver status, effective demand rule, and output location. The result workbook records actual solver status, objective, effective demand settings, historical load factors, per-flight phi, and route demand audits. It can be opened in Excel; the root Markdown report and CSV are readable directly in VS Code. Do not infer the scenario only from cost: LF80 and uniform phi1.20 happen to have equal objective/spill totals for the supplied data.

DB1B observations remain unavailable. Spill penalties remain labeled cost-recovery proxies unless real directional fares are supplied. Estimated spill does not establish observed overbooking, denied boarding, or lost fare revenue.
