# Primary Result: Conditional Historical LF80

The primary scenario applies phi=1.20 only when historical directional-route LF is strictly greater than 0.80; other routes use phi=1.00. LF is historical passengers divided by historical seats, before optimization.

| Metric | Result |
|---|---:|
| Gurobi status | OPTIMAL_WITHIN_CONFIGURED_TOLERANCE |
| Total objective | USD 3,361,858.29 |
| Operating expense | USD 3,201,237.68 |
| Spill penalty | USD 160,620.61 |
| Estimated spilled passenger-equivalents | 820.359731 |
| Flights with spill | 54 / 204 |
| Routes / flights receiving uplift | 51 / 81 |
| MIP gap | 0.000000% |
| Automated tests passed | 59 |

The original common-event coverage, integer inventory, cyclic flow, readiness, fleet caps, spill, and objective checks passed. The three source Excel files remain unchanged.

Primary evidence: `validation/primary_lf80/gurobi_results.xlsx`, `run_summary.json`, `RUN_REPORT.md`, and `gurobi.log` in the same folder.

## Separately labeled comparisons

| Scenario | Role | Estimated spill | Flights with spill | Objective USD |
|---|---|---:|---:|---:|
| historical_mean | BENCHMARK | 0.000000 | 0 | 3,201,237.68 |
| lf_strictly_above_0.8 | PRIMARY_RULE_COMPARISON | 820.359731 | 54 | 3,361,858.29 |
| lf_strictly_above_0.9 | SENSITIVITY | 497.802150 | 18 | 3,299,554.57 |
| lf_strictly_above_0.95 | SENSITIVITY | 0.000000 | 0 | 3,201,237.68 |

The comparison workbook is `validation/load_factor_comparison/Load_Factor_Comparison.xlsx`. Uniform-phi stress tests remain a separate optional experiment through `run_sensitivity.py`; no old uniform-primary result folder is included in this distribution.

DB1B fares remain unavailable. Spill penalties use the explicitly labeled cost-recovery proxy, not an observed ticket fare or actual lost revenue. Spill is estimated demand above assigned capacity, not measured denied boarding. The PDF permits a documented demand adjustment but does not prescribe the chosen 80% cutoff or 1.20 multiplier.
