"""Protect the VS Code result view from stale assignments or old reports."""
from contextlib import redirect_stdout
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import solve_and_show


class VSCodeRunnerTests(unittest.TestCase):
    def test_new_run_publishes_report_and_assignment_csv(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)

            def solve(arguments):
                output = Path(arguments[arguments.index("--output") + 1])
                self.assertEqual(output.parent, root / "results")
                output.mkdir(parents=True)
                (output / "RUN_REPORT.md").write_text("Current scenario: LF80; status OPTIMAL.")
                (output / "assignments.csv").write_text("flight_id,aircraft_type\nHA1,696\n")
                return 0

            with patch.object(solve_and_show, "ROOT", root), \
                    patch.object(solve_and_show, "run_model", side_effect=solve), \
                    redirect_stdout(io.StringIO()):
                self.assertEqual(solve_and_show.main([]), 0)
            self.assertIn("Current scenario: LF80", (root / "LATEST_RESULTS.md").read_text())
            self.assertIn("HA1,696", (root / "LATEST_assignments.csv").read_text())

    def test_failed_current_run_replaces_report_and_removes_stale_assignment(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            output = root / "explicit_output"
            (root / "LATEST_RESULTS.md").write_text("OLD SUCCESS")
            (root / "LATEST_assignments.csv").write_text("OLD ASSIGNMENTS")

            def fail(arguments):
                self.assertEqual(Path(arguments[arguments.index("--output") + 1]), output)
                output.mkdir()
                (output / "RUN_REPORT.md").write_text("Current run: EXECUTION_ERROR.")
                return 1

            with patch.object(solve_and_show, "ROOT", root), \
                    patch.object(solve_and_show, "run_model", side_effect=fail), \
                    redirect_stdout(io.StringIO()):
                self.assertEqual(solve_and_show.main(["--output", str(output)]), 1)
            self.assertIn("EXECUTION_ERROR", (root / "LATEST_RESULTS.md").read_text())
            self.assertNotIn("OLD SUCCESS", (root / "LATEST_RESULTS.md").read_text())
            self.assertFalse((root / "LATEST_assignments.csv").exists())

    def test_refused_existing_output_does_not_publish_its_previous_solution(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            output = root / "existing"
            output.mkdir()
            (output / "RUN_REPORT.md").write_text("OLD OPTIMAL SOLUTION")
            (output / "assignments.csv").write_text("OLD FLIGHT ASSIGNMENT")
            (root / "LATEST_assignments.csv").write_text("STALE ROOT ASSIGNMENT")
            with patch.object(solve_and_show, "ROOT", root), \
                    patch.object(solve_and_show, "run_model", return_value=1), \
                    redirect_stdout(io.StringIO()):
                self.assertEqual(solve_and_show.main(["--output", str(output)]), 1)
            report = (root / "LATEST_RESULTS.md").read_text()
            self.assertIn("did not produce a new completed run report", report)
            self.assertNotIn("OLD OPTIMAL SOLUTION", report)
            self.assertFalse((root / "LATEST_assignments.csv").exists())


if __name__ == "__main__":
    unittest.main()
